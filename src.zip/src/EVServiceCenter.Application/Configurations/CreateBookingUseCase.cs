// Sample use case
